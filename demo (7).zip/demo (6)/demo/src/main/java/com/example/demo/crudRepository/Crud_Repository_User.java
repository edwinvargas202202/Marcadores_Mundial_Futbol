package com.example.demo.crudRepository;

import com.example.demo.model.User;
import com.example.demo.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Crud_Repository_User extends JpaRepository<User,String> {

}
